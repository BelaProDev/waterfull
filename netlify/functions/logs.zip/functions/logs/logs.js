var import_neon = require("@netlify/neon");
const sql = (0, import_neon.neon)();
const apiKey = process.env.VITE_X_API_KEY;
exports.handler = async (event, context) => {
  const requestKey = event.headers["x-api-key"];
  if (apiKey === requestKey) {
    const data = JSON.parse(event.body);
    const Adata = Array.from(Object.entries(data), ([key, value]) => value);
    console.log(Adata);
    try {
      const response = await sql`INSERT INTO logs_f4fp2sk9h45(latlng,timestamp,timezone,locale,page) VALUES (${Adata[0]},CURRENT_TIMESTAMP,${Adata[2]},${Adata[3]},${Adata[4]})`;
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: "Successfully created document",
          data: response
        })
      };
    } catch (error) {
      console.log(error);
      return {
        statusCode: 400,
        body: JSON.stringify({
          error
        })
      };
    }
  } else {
    return {
      statusCode: 500,
      body: "DENIED"
    };
  }
};
